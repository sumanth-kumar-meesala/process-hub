PROCESS HUB — how to put it on the intranet
===========================================

What it is
  A static website: HTML, JavaScript, CSS and an icon. No server code, no database,
  no install, nothing to configure on the server. About 1.8 MB.

How to publish
  1. Copy this whole "process-hub" folder to any intranet web server, for example
     https://intranet.<company>/process-hub/
     (IIS, Apache, nginx, an Azure Static Web App, or any server that serves files).
  2. Open https://intranet.<company>/process-hub/  — that's it.

  It works from any folder name, and its pages use "#" links
  (e.g. .../process-hub/#/process/fs25-client-specific-training),
  so no URL-rewrite rules are needed.

Server notes
  - Serve index.html as the default document for the folder.
  - .js files must be served as JavaScript (application/javascript or text/javascript);
    .svg as image/svg+xml. Most servers do this already.
  - HTTPS is recommended (the browser saves each person's data locally; that works on
    HTTP too, but HTTPS is better practice).

Good to know
  - Data: processes people build are saved in each person's own browser
    (IndexedDB). Nothing is sent to or stored on the server.
  - Outside connections: it loads a font from fonts.googleapis.com (if blocked, a
    standard system font is used instead — no other effect). The AI assistant calls
    api.groq.com only if someone adds a key in Admin; this copy contains NO key.
  - Browsers: current Chrome, Edge, Firefox or Safari. The 3D map needs WebGL
    (standard in all of these); without it a plain list of stages is shown instead.

Updating
  Replace the folder's contents with a newer copy.
